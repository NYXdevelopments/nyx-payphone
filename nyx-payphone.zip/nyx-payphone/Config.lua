Config = {}

Config.limit = 8 -- how many numbers you can put in the payphone

Config.pay = 100 -- how much money you need to pay per minute

Config.moneytype = 'cash' -- you can put cash or bank to use one of them remove