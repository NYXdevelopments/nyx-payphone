import { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import $ from "jquery";
import "./App.css";

function App() {
  const [display, setDisplay] = useState("Press a Button");
  const [limit, setLimit] = useState();

  window.addEventListener("message", function (event) {
    if (event.data.action === "showPayPhone") {
      let root = document.getElementById("root");
      root.style.display = "flex";
      setLimit(event.data.numberlimit);
      setDisplay("Press a Button");
    } else if (event.data.action === "hidePayPhone") {
      let root = document.getElementById("root");
      root.style.display = "none";
      setDisplay("Press a Button");
    }
  });
  document.onkeyup = function (data) {
    if (data.key == "Escape") {
      $.post("https://nyx-payphone/escape", JSON.stringify({}));
    }
  };
  function triggerCall() {
    if (display.length === limit) {
      toast.success(`Dialling ${display}`);
      $.post(
        "https://nyx-payphone/dialnumber",
        JSON.stringify({
          number: display,
        })
      );
    } else {
      toast.error(`Error: Lengh Must be ${limit} numbers`);
    }
  }

  return (
    <>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={true}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
      />
      <div className="container">
        <div className="form">
          <div className="inner">
            <div className="Title">PUBLIC PAYPHONE</div>
            <div className="line"></div>
            <div className="line2"></div>
            <div className="display">{display}</div>
            <div className="keypad">
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("1");
                  } else {
                    setDisplay(display + "1");
                  }
                }}
              >
                1
              </button>
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("2");
                  } else {
                    setDisplay(display + "2");
                  }
                }}
              >
                2
              </button>
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("3");
                  } else {
                    setDisplay(display + "3");
                  }
                }}
              >
                3
              </button>
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("4");
                  } else {
                    setDisplay(display + "4");
                  }
                }}
              >
                4
              </button>
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("5");
                  } else {
                    setDisplay(display + "5");
                  }
                }}
              >
                5
              </button>
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("6");
                  } else {
                    setDisplay(display + "6");
                  }
                }}
              >
                6
              </button>
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("7");
                  } else {
                    setDisplay(display + "7");
                  }
                }}
              >
                7
              </button>
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("8");
                  } else {
                    setDisplay(display + "8");
                  }
                }}
              >
                8
              </button>
              <button
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("9");
                  } else {
                    setDisplay(display + "9");
                  }
                }}
              >
                9
              </button>
              <button
                className="zero"
                onClick={() => {
                  if (display === "Press a Button") {
                    setDisplay("0");
                  } else {
                    setDisplay(display + "0");
                  }
                }}
              >
                0
              </button>
              <button
                className="delete"
                onClick={() => {
                  if (display >= 0) setDisplay(display.slice(0, -1));
                }}
              >
                {/* &#9003; */}
                <i class="material-icons">backspace</i>
              </button>
              <button className="call" colSpan="3" onClick={triggerCall}>
                <i class="fa fa-phone"></i>
                <div className="caller">Call</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
